package com.ecom.controller;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ecom.model.Category;
import com.ecom.model.InvoiceItemDTO;
import com.ecom.model.Make;
import com.ecom.model.Part;
import com.ecom.model.Product;
import com.ecom.repository.PartRepository;
import com.ecom.service.PartService;
import com.ecom.service.ProductService;
//import com.ecom.model.UserDtls;
//import com.ecom.service.CartService;
//import com.ecom.service.CategoryService;
//import com.ecom.service.ProductService;
//import com.ecom.service.UserService;
//import com.ecom.service.impl.CategoryServiceImpl;
//import com.ecom.util.CommonUtil;
import com.ecom.service.impl.CategoryServiceImpl;
import com.ecom.service.impl.PartServiceImpl;

import io.micrometer.common.util.StringUtils;
//import jakarta.mail.MessagingException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {

	@Autowired
	private CategoryServiceImpl categoryService;

	@Autowired
	private ProductService productService;

	@Autowired
    private PartServiceImpl partService;
	
	@Autowired
	private PartRepository partRepository;
	
	@GetMapping("/")
	public String index() {
		return "index";
	}

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	@GetMapping("/register")
	public String register() {
		return "register";
	}

	@GetMapping("/products")
	public String products(Model m, @RequestParam(value = "category", defaultValue = "") String category,
			@RequestParam(name = "pageNo", defaultValue = "0") Integer pageNo,
			@RequestParam(name = "pageSize", defaultValue = "12") Integer pageSize,
			@RequestParam(defaultValue = "") String ch) {

		List<Category> categories = categoryService.getAllActiveCategory();
		m.addAttribute("paramValue", category);
		m.addAttribute("categories", categories);

//		List<Product> products = productService.getAllActiveProducts(category);
//		m.addAttribute("products", products);
		Page<Product> page = null;
		if (StringUtils.isEmpty(ch)) {
			page = productService.getAllActiveProductPagination(pageNo, pageSize, category);
		} else {
			page = productService.searchActiveProductPagination(pageNo, pageSize, category, ch);
		}

		List<Product> products = page.getContent();
		m.addAttribute("products", products);
		m.addAttribute("productsSize", products.size());

		m.addAttribute("pageNo", page.getNumber());
		m.addAttribute("pageSize", pageSize);
		m.addAttribute("totalElements", page.getTotalElements());
		m.addAttribute("totalPages", page.getTotalPages());
		m.addAttribute("isFirst", page.isFirst());
		m.addAttribute("isLast", page.isLast());

		return "product";
	}

	@GetMapping("/product")
	public String view_product() {
		return "view_product";
	}

	@GetMapping("/job_card")
	public String job_card() {
		return "job_card";
	}

	/*---------------------------------------------------------------------*/
	
	 @GetMapping("/add_part")
	    public String add_part()
	    {
	    	return "add_part";
	    }
	    
	 
	 
	 @GetMapping("/parts")
	    public String parts()
	    {
	    	return "parts";
	    }
	 
	 @GetMapping("/parts/edit/{id}")
	    public String editPartForm(@PathVariable Long id, Model model) {
	        Part part = partService.getPartById(id);
	        model.addAttribute("part", part);
	        return "edit_part"; // Thymeleaf template
	    }

	    @PostMapping("/parts/update/{id}")
	    public String updatePart(@PathVariable Long id, @ModelAttribute Part updatedPart) {
	        Part existing = partService.getPartById(id);
	        if (existing != null) {
	            existing.setPartNumber(updatedPart.getPartNumber());
	            existing.setDescription(updatedPart.getDescription());
	            existing.setType(updatedPart.getType());
	            existing.setStatus(updatedPart.getStatus());
	            existing.setRate(updatedPart.getRate());
	            existing.setMrp(updatedPart.getMrp());
	            existing.setDiscount(updatedPart.getDiscount());
	            existing.setVendorName(updatedPart.getVendorName());
	            existing.setVendorInvoiceNo(updatedPart.getVendorInvoiceNo());

	            double amt = updatedPart.getRate() * existing.getStock();
	            double finalAmt = amt - (amt * updatedPart.getDiscount() / 100);
	            existing.setAmt(amt);
	            existing.setFinalAmt(finalAmt);

	            partService.savePart(existing);
	        }
	        return "redirect:/inventory";
	    }

	    
	   
	   
	   
	 
	 
	 /*---------------------------------------------------------------------*/

	    
	    @GetMapping("/add_invoice")
		public String add_invoice() {
			return "/admin/add_invoice";
		}
		
		@GetMapping("/add_part_entry")
		public String button_view_invoice() {
			return "admin/add_part_entry";
		}
		
		 @GetMapping("/inventory")
		    public String showInventory(Model model) {
		        model.addAttribute("parts", partService.getAllParts());
		        model.addAttribute("content", "inventory :: content"); 
		        return "inventory"; // Thymeleaf template name
		    }
		 
		    @GetMapping("/invoice")
		    public String showinvoice() {
		        //model.addAttribute("parts", partService.getAllParts());
		        return "invoice"; // Thymeleaf template name
		    }
		    
		    @GetMapping("/invoice-form")
		    public String showInvoiceForm() {
		        return "invoice-form"; // This will load invoice-form.html from templates folder
		    }
}
