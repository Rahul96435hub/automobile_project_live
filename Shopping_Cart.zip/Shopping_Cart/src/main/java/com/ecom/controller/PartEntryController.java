package com.ecom.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ecom.model.PartEntry;
import com.ecom.repository.PartEntryRepository;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import jakarta.servlet.http.HttpServletResponse;

public class PartEntryController {
	
	@Autowired
    private PartEntryRepository partEntryRepository;
	
	@GetMapping("/parts/export-pdf")
    public void exportPartsToPdf(HttpServletResponse response) throws IOException, DocumentException {
 {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=parts_entry.pdf");

        List<PartEntry> parts = partEntryRepository.findAll(); // get from DB

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Document document = new Document();
        PdfWriter.getInstance(document, baos);
        document.open();

        document.add(new Paragraph("Parts Entry Report"));
        PdfPTable table = new PdfPTable(7); // columns: Part No, Desc, Type, Qty, Rate, Discount, Amount

        Stream.of("Part No", "Desc", "Type", "Qty", "Rate", "Discount", "Amount").forEach(header -> {
            PdfPCell cell = new PdfPCell(new Phrase(header));
            cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            table.addCell(cell);
        });

        for (PartEntry part : parts) {
            table.addCell(part.getPartNumber());
            table.addCell(part.getDescription());
            table.addCell(part.getType());
            table.addCell(String.valueOf(part.getQty()));
            table.addCell(String.valueOf(part.getRate()));
            table.addCell(String.valueOf(part.getDiscount()));
            table.addCell(String.valueOf(part.getAmount()));
        }

        document.add(table);
        document.close();

        response.getOutputStream().write(baos.toByteArray());
    }
    }
    
    @PostMapping("/api/parts/save")
    public ResponseEntity<String> saveParts(@RequestBody List<PartEntry> parts) {
        partEntryRepository.saveAll(parts);
        return ResponseEntity.ok("Saved successfully");
    }


}
