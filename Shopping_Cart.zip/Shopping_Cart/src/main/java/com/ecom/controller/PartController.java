package com.ecom.controller;

import com.ecom.model.CheckDTO;
import com.ecom.model.Part;
import com.ecom.model.PartEntry;
import com.ecom.repository.PartEntryRepository;
import com.ecom.repository.PartRepository;
import com.ecom.service.JobcardService;
import com.ecom.service.PartService;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

@RestController
@RequestMapping("/api/parts")
@CrossOrigin(origins = "*")
public class PartController {

	 @Autowired
	    private PartRepository partRepository;
    @Autowired
    private PartEntryRepository partEntryRepository;
    
    @Autowired
    private PartService partService;
    
    

    // 1) GET all parts
    @GetMapping
    public ResponseEntity<List<Part>> getAllParts() {
        return ResponseEntity.ok(partRepository.findAll());
    }

    // 2) GET part by partNumber
    @GetMapping("/{partNumber}")
    public ResponseEntity<?> getPart(@PathVariable String partNumber) {
        Part part = partRepository.findByPartNumber(partNumber);
        if (part != null) {
            return ResponseEntity.ok(part);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Part not found: " + partNumber);
        }
    }

    // 3) ADD new part
    @PostMapping
    public ResponseEntity<?> addPart(@RequestBody Part incoming) {
        if (partRepository.existsByPartNumber(incoming.getPartNumber())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("Part already exists: " + incoming.getPartNumber());
        }

        double amt = incoming.getRate() * incoming.getStock();
        double finalAmt = amt - (amt * incoming.getDiscount() / 100.0);
        incoming.setAmt(amt);
        incoming.setFinalAmt(finalAmt);

        Part saved = partRepository.save(incoming);
        URI location = URI.create("/api/parts/" + saved.getPartNumber());
        return ResponseEntity.created(location).body(saved);
    }

    // 4) UPDATE stock by ID
    @PutMapping("/{id}/stock")
    public ResponseEntity<?> updateStock(@PathVariable Long id, @RequestParam int stock) {
        Optional<Part> opt = partRepository.findById(id);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();

        Part p = opt.get();
        p.setStock(stock);
        partRepository.save(p);
        return ResponseEntity.ok(p);
    }

    // 5) CHECK & reserve stock using CheckDTO
    @PostMapping("/check-stock")
    public ResponseEntity<?> checkAndReserve(@RequestBody CheckDTO dto) {
        Part part = partRepository.findByPartNumber(dto.getPartNumber()); // direct Part object

        if (part == null) {  // null check karo kyunki Optional nahi hai
            return ResponseEntity.status(404).body("Part not found");
        }

        if (part.getStock() < dto.getQty()) {
            return ResponseEntity.status(400).body("Insufficient stock");
        }

        part.setStock(part.getStock() - dto.getQty());
        partRepository.save(part);

        return ResponseEntity.ok("Stock updated");
    }


    // 6) SHIP and record entries using List<PartEntry>
    @PostMapping("/ship")
    public ResponseEntity<?> ship(@RequestBody List<PartEntry> entries) {
        for (PartEntry e : entries) {
            Part part = partRepository.findByPartNumber(e.getPartNumber());
            if (part != null) {  // null check instead of ifPresent
                part.setStatus("Shipped");
                partRepository.save(part);
            }
        }

        partEntryRepository.saveAll(entries);
        return ResponseEntity.ok("All parts shipped and entries recorded.");
    }


    // 7) SAVE entries directly
    @PostMapping("/save-entries")
    public ResponseEntity<String> saveEntries(@RequestBody List<PartEntry> entries) {
        partEntryRepository.saveAll(entries);
        return ResponseEntity.ok("Entries saved");
    }

    // 8) EXPORT part entries to PDF
    @GetMapping("/export-pdf")
    public void exportToPdf(HttpServletResponse response) throws IOException, DocumentException {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=parts_entry.pdf");

        List<PartEntry> entries = partEntryRepository.findAll();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Document doc = new Document();
        PdfWriter.getInstance(doc, baos);
        doc.open();

        doc.add(new Paragraph("Parts Entry Report"));

        PdfPTable table = new PdfPTable(7);
        Stream.of("Part No", "Desc", "Type", "Qty", "Rate", "Discount", "Amount")
                .forEach(header -> {
                    PdfPCell cell = new PdfPCell(new Phrase(header));
                    cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
                    table.addCell(cell);
                });

        for (PartEntry e : entries) {
            table.addCell(e.getPartNumber());
            table.addCell(e.getDescription());
            table.addCell(e.getType());
            table.addCell(String.valueOf(e.getQty()));
            table.addCell(String.valueOf(e.getRate()));
            table.addCell(String.valueOf(e.getDiscount()));
            table.addCell(String.valueOf(e.getAmount()));
        }

        doc.add(table);
        doc.close();
        response.getOutputStream().write(baos.toByteArray());
    }
    
   
    
   
}
