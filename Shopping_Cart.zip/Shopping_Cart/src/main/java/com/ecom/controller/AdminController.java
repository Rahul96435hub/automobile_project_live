package com.ecom.controller;


import java.io.File;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ecom.model.Category;
import com.ecom.model.Jobcard;
import com.ecom.model.Make;
import com.ecom.model.Product;
import com.ecom.service.CategeoryService;
import com.ecom.service.JobcardService;
import com.ecom.service.MakeService;
import com.ecom.service.ModelService;
import com.ecom.service.ProductService;
import com.ecom.service.impl.PartServiceImpl;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.bind.annotation.GetMapping;
import java.io.IOException;

import jakarta.servlet.http.HttpSession;

import org.springframework.data.domain.Page;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private CategeoryService categoryService;

	@Autowired
	private ProductService productService;
	
	@Autowired
    private PartServiceImpl partService;

	@GetMapping("/")
	public String index() {
		return "admin/index";
	}

	@GetMapping("/loadAddProduct")
	public String loadAddProduct(Model m) {
		List<Category> categories = categoryService.getAllCategory();
		m.addAttribute("categories", categories);
		return "admin/add_product";
	}
	/* Start Category */

	@GetMapping("/category")
	public String category(Model m) {
		m.addAttribute("categorys", categoryService.getAllCategory());
		return "admin/category";
	}

	@PostMapping("/saveCategory")
	public String saveCategory(@ModelAttribute Category category, @RequestParam("file") MultipartFile file,
			HttpSession session) throws IOException {

		String imageName = file != null ? file.getOriginalFilename() : "default.jpg";
		category.setImageName(imageName);

		Boolean existCatgory = categoryService.existCatgory(category.getName());
		if (existCatgory) {
			session.setAttribute("errorMsg", "Category Name alredy exists");
		} else {

			Category saveCategory = categoryService.saveCategory(category);

			if (ObjectUtils.isEmpty(saveCategory)) {
				session.setAttribute("errorMsg", "Not saved ! Internal server error");
			} else {

				File saveFile = new ClassPathResource("static/img").getFile();

				Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + "category_img" + File.separator
						+ file.getOriginalFilename());

				// System.out.println(path);
				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

				session.setAttribute("succMsg", "Save successfully");
			}
		}

		return "redirect:/admin/category";
	}

	@GetMapping("/deleteCategory/{id}")
	public String deleteCategory(@PathVariable int id, HttpSession session) {
		Boolean deleteCategory = categoryService.deleteCategory(id);

		if (deleteCategory) {
			session.setAttribute("succMsg", "category delete success");
		} else {
			session.setAttribute("errorMsg", "something wrong on server");
		}

		return "redirect:/admin/category";
	}

	@GetMapping("/loadEditCategory/{id}")
	public String loadEditCategory(@PathVariable int id, Model m) {
		m.addAttribute("category", categoryService.getCategoryById(id));
		return "admin/edit_category";
	}

	@PostMapping("/updateCategory")
	public String updateCategory(@ModelAttribute Category category, @RequestParam("file") MultipartFile file,
			HttpSession session) throws IOException {

		Category oldCategory = categoryService.getCategoryById(category.getId());
		String imageName = file.isEmpty() ? oldCategory.getImageName() : file.getOriginalFilename();

		if (!ObjectUtils.isEmpty(category)) {

			oldCategory.setName(category.getName());
			oldCategory.setIsActive(category.getIsActive());
			oldCategory.setImageName(imageName);
		}

		Category updateCategory = categoryService.saveCategory(oldCategory);

		if (!ObjectUtils.isEmpty(updateCategory)) {

			if (!file.isEmpty()) {
				File saveFile = new ClassPathResource("static/img").getFile();

				Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + "category_img" + File.separator
						+ file.getOriginalFilename());

				// System.out.println(path);
				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			}

			session.setAttribute("succMsg", "Category update success");
		} else {
			session.setAttribute("errorMsg", "something wrong on server");
		}

		return "redirect:/admin/loadEditCategory/" + category.getId();
	}

	/* END Category */

	@PostMapping("/saveProduct")
	public String saveProduct(@ModelAttribute Product product, @RequestParam("file") MultipartFile image,
			HttpSession session) throws IOException {

		String imageName = image.isEmpty() ? "default.jpg" : image.getOriginalFilename();

		product.setImage(imageName);
		product.setDiscount(0);
		product.setDiscountPrice(product.getPrice());
		Product saveProduct = productService.saveProduct(product);

		if (!ObjectUtils.isEmpty(saveProduct)) {

			File saveFile = new ClassPathResource("static/img").getFile();

			Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + "product_img" + File.separator
					+ image.getOriginalFilename());

			System.out.println(path);
			Files.copy(image.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

			session.setAttribute("succMsg", "Product Saved Success");
		} else {
			session.setAttribute("errorMsg", "something wrong on server");
		}

		return "redirect:/admin/loadAddProduct";
	}

	/*
	 * @GetMapping("/products")
	 * 
	 * public String loadviewProduct(Model m) { m.addAttribute("products",
	 * productService.getAllProducts()); return "admin/products"; }
	 */

	@GetMapping("/products")
	public String loadViewProduct(Model m, @RequestParam(defaultValue = "") String ch,
			@RequestParam(name = "pageNo", defaultValue = "0") Integer pageNo,
			@RequestParam(name = "pageSize", defaultValue = "10") Integer pageSize) {

//		List<Product> products = null;
//		if (ch != null && ch.length() > 0) {
//			products = productService.searchProduct(ch);
//		} else {
//			products = productService.getAllProducts();
//		}
//		m.addAttribute("products", products);

		Page<Product> page = null;
		if (ch != null && ch.length() > 0) {
			page = productService.searchProductPagination(pageNo, pageSize, ch);
		} else {
			page = productService.getAllProductsPagination(pageNo, pageSize);
		}
		m.addAttribute("products", page.getContent());

		m.addAttribute("pageNo", page.getNumber());
		m.addAttribute("pageSize", pageSize);
		m.addAttribute("totalElements", page.getTotalElements());
		m.addAttribute("totalPages", page.getTotalPages());
		m.addAttribute("isFirst", page.isFirst());
		m.addAttribute("isLast", page.isLast());

		return "admin/products";
	}

	@GetMapping("/deleteProduct/{id}")
	public String deleteProduct(@PathVariable int id, HttpSession session) {
		Boolean deleteProduct = productService.deleteProduct(id);
		if (deleteProduct) {
			session.setAttribute("succMsg", "Product delete success");
		} else {
			session.setAttribute("errorMsg", "Something wrong on server");
		}
		return "redirect:/admin/products";
	}

	@GetMapping("/editProduct/{id}")
	public String editProduct(@PathVariable int id, Model m) {
		m.addAttribute("product", productService.getProductById(id));
		m.addAttribute("categories", categoryService.getAllCategory());
		return "admin/edit_product";
	}

	@PostMapping("/updateProduct")
	public String updateProduct(@ModelAttribute Product product, @RequestParam("file") MultipartFile image,
			HttpSession session, Model m) {

		if (product.getDiscount() < 0 || product.getDiscount() > 100) {
			session.setAttribute("errorMsg", "invalid Discount");
		} else {
			Product updateProduct = productService.updateProduct(product, image);
			if (!ObjectUtils.isEmpty(updateProduct)) {
				session.setAttribute("succMsg", "Product update success");
			} else {
				session.setAttribute("errorMsg", "Something wrong on server");
			}
		}
		return "redirect:/admin/editProduct/" + product.getId();
	}

	/* End Product Code */

	/*-------------------------------------------------------------------------------------------------------------------------------*/

	/* Start Make Code */

	@Autowired
	private MakeService makeService;

	/*
	 * @GetMapping("/make") public String make(Model m) { m.addAttribute("makes",
	 * makeService.getAllMake()); return "admin/make"; }
	 */

	@PostMapping("/saveMake")
	public String saveMake(@ModelAttribute Make make, @RequestParam("file") MultipartFile file, HttpSession session)
			throws IOException {

		String imageName = file != null ? file.getOriginalFilename() : "default.jpg";
		make.setImageName(imageName);

		Boolean existMake = makeService.existMake(make.getName());
		if (existMake) {
			session.setAttribute("errorMsg", "Make name already exists");
		} else {
			Make savedMake = makeService.saveMake(make);

			if (ObjectUtils.isEmpty(savedMake)) {
				session.setAttribute("errorMsg", "Not saved! Internal server error");
			} else {
				File saveFile = new ClassPathResource("static/img").getFile();

				Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + "make_img" + File.separator
						+ file.getOriginalFilename());

				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

				session.setAttribute("succMsg", "Saved successfully");
			}
		}

		return "redirect:/admin/make";
	}

	@GetMapping("/deleteMake/{id}")
	public String deleteMake(@PathVariable int id, HttpSession session) {
		boolean isDeleted = makeService.deleteMake(id);

		if (isDeleted) {
			session.setAttribute("succMsg", "Make deleted successfully.");
		} else {
			session.setAttribute("errorMsg", "Something went wrong on the server.");
		}

		return "redirect:/admin/make";
	}

	@GetMapping("/loadEditMake/{id}")
	public String loadEditMake(@PathVariable int id, Model m) {
		m.addAttribute("make", makeService.getMakeById(id));
		return "admin/edit_make";
	}

	@PostMapping("/updateMake")
	public String updateMake(@ModelAttribute Make make, @RequestParam("file") MultipartFile file, HttpSession session)
			throws IOException {

		Make oldMake = makeService.getMakeById(make.getId());
		String imageName = file.isEmpty() ? oldMake.getImageName() : file.getOriginalFilename();

		if (!ObjectUtils.isEmpty(make)) {

			oldMake.setName(make.getName());
			oldMake.setIsActive(make.getIsActive());
			oldMake.setImageName(imageName);
		}

		Make updatedMake = makeService.saveMake(oldMake);

		if (!ObjectUtils.isEmpty(updatedMake)) {

			if (!file.isEmpty()) {
				File saveFile = new ClassPathResource("static/img").getFile();

				Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + "make_img" + File.separator
						+ file.getOriginalFilename());

				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			}

			session.setAttribute("succMsg", "Make update success");
		} else {
			session.setAttribute("errorMsg", "something wrong on server");
		}

		return "redirect:/admin/loadEditMake/" + make.getId();

	}

	/*-----------------------------------------------------------------------------------------------------------------------------------*/

	/* Start Make pigion Page crate */
	@GetMapping("/make")
	public String loadViewMakes(Model m, @RequestParam(defaultValue = "") String keyword,
			@RequestParam(defaultValue = "0") int pageNo, @RequestParam(defaultValue = "5") int pageSize) {

		Page<Make> page;
		if (!keyword.isEmpty()) {
			page = makeService.searchMakePagination(pageNo, pageSize, keyword);
		} else {
			page = makeService.getAllMakePagination(pageNo, pageSize);
		}

		m.addAttribute("makes", page.getContent());
		m.addAttribute("pageNo", page.getNumber());
		m.addAttribute("pageSize", pageSize);
		m.addAttribute("totalElements", page.getTotalElements());
		m.addAttribute("totalPages", page.getTotalPages());
		m.addAttribute("isFirst", page.isFirst());
		m.addAttribute("isLast", page.isLast());
		m.addAttribute("keyword", keyword);

		return "admin/make";
	}

	/* End Make pigion Page crate */

	/* End Make Code */
	/*-----------------------------------------------------------------------------------------------------------------------------------*/
	/* Start Model Code */

	@Autowired
	private ModelService modelService;

	@GetMapping("/model")
	public String modelList(Model m) {
		m.addAttribute("models", modelService.getAllModel());
		return "admin/model";
	}

	/*
	 * @PostMapping("/saveModel") public String saveModel(@ModelAttribute
	 * com.ecom.model.Model model) { modelService.saveModel(model); // yeh sahi hai
	 * return "redirect:/admin/model"; }
	 */
	@PostMapping("/saveModel")
	public String saveModel(@ModelAttribute com.ecom.model.Model model, HttpSession session) {

		// Check if model with the same name already exists
		boolean exists = modelService.existModel(model.getName());

		if (exists) {
			session.setAttribute("errorMsg", "Model with this name already exists!");
			return "redirect:/admin/model";
		}

		// Save model
		com.ecom.model.Model savedModel = modelService.saveModel(model);

		if (savedModel != null) {
			session.setAttribute("succMsg", "Model saved successfully!");
		} else {
			session.setAttribute("errorMsg", "Internal Server Error! Model not saved.");
		}

		return "redirect:/admin/model";
	}

	@GetMapping("/deleteModel/{id}")
	public String deleteModel(@PathVariable int id, HttpSession session) {
		boolean isDeleted = modelService.deleteModel(id);

		if (isDeleted) {
			session.setAttribute("succMsg", "Model deleted successfully.");
		} else {
			session.setAttribute("errorMsg", "Something went wrong on the server.");
		}

		return "redirect:/admin/model";
	}

	@GetMapping("/loadEditModel/{id}")
	public String loadEditModel(@PathVariable int id, Model m) {
		m.addAttribute("model", modelService.getModelById(id));
		return "admin/edit_model";
	}

	@PostMapping("/updateModel")
	public String updateModel(@ModelAttribute com.ecom.model.Model model, HttpSession session) {

		com.ecom.model.Model oldModel = modelService.getModelById(model.getId());

		if (!ObjectUtils.isEmpty(model)) {
			oldModel.setName(model.getName());
			oldModel.setIsActive(model.getIsActive());
		}

		com.ecom.model.Model updatedModel = modelService.saveModel(oldModel);

		if (!ObjectUtils.isEmpty(updatedModel)) {
			session.setAttribute("succMsg", "Model updated successfully");
		} else {
			session.setAttribute("errorMsg", "Something went wrong on the server");
		}

		return "redirect:/admin/loadEditModel/" + model.getId();
	}
	/* Strat pagination Model */
	
	@GetMapping("/admin/model") // Keep this for the first method
    public String loadViewModel(org.springframework.ui.Model model, @RequestParam(defaultValue = "") String keyword,
        @RequestParam(defaultValue = "0") int pageNo, @RequestParam(defaultValue = "5") int pageSize) {

        Page<com.ecom.model.Model> page;

        if (!keyword.isEmpty()) {
            page = modelService.searchModelPagination(pageNo, pageSize, keyword);
        } else {
            page = modelService.getAllModelPagination(pageNo, pageSize);
        }

        model.addAttribute("pageNo", page.getNumber());
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("totalElements", page.getTotalElements());
        model.addAttribute("totalPages", page.getTotalPages());
        model.addAttribute("isFirst", page.isFirst());
        model.addAttribute("isLast", page.isLast());
        model.addAttribute("keyword", keyword);

        return "admin/model";
    }

   
  


	/* End Model Code */

	/* Start Jobcard Code */

	

	@Autowired
	private JobcardService jobcardService;

	@GetMapping("/loadAddJobcard")
	public String loadAddJobcard(Model model) {
		List<Category> categories = categoryService.getAllActiveCategory();
		model.addAttribute("categories", categories);

		List<Make> make = makeService.getAllActiveMake();
		model.addAttribute("makes", make);

		List<com.ecom.model.Model> models = modelService.getAllActiveModel();
		model.addAttribute("models", models);

		return "admin/add_job_card";
	}

	@PostMapping("/saveJobcard")
	public String saveJobcard(@ModelAttribute Jobcard jobcard, HttpSession session) {

		// Auto-generate job card number
		String jobCardNumber = "JOB" + System.currentTimeMillis();
		jobcard.setJobCardNumber(jobCardNumber);

		// Set job date and time if not provided
		if (jobcard.getJobDate() == null) {
			jobcard.setJobDate(LocalDate.now());
		}
		if (jobcard.getJobTime() == null) {
			jobcard.setJobTime(LocalTime.now());
		}

		Jobcard saved = jobcardService.saveJobcard(jobcard);

		if (saved != null) {
			session.setAttribute("succMsg", "Jobcard Saved Successfully");
		} else {
			session.setAttribute("errorMsg", "Something went wrong on the server");
		}

		return "redirect:/admin/loadAddJobcard"; // Change to your appropriate redirect
	}

	
	
	  
	
	  @GetMapping("/editJobcard/{id}") 
	  public String editJobcard(@PathVariable Integer id, Model model) 
	  { 
		  //System.out.println("Returning view: admin/editJobcard");
	  Jobcard jobcard = jobcardService.getJobcardById(id); 
	  model.addAttribute("jobcard", jobcard);
	  model.addAttribute("categories", categoryService.getAllActiveCategory());
	  model.addAttribute("makes", makeService.getAllActiveMake());
	  model.addAttribute("models", modelService.getAllActiveModel()); 
	  return "admin/edit_jobcard"; // <-- Make sure this view exists 
	  }
	 
		
	  
	  @PostMapping("/updateJobcard")
	  public String updateJobcard(@ModelAttribute Jobcard jobcard, HttpSession session) {

	      Jobcard oldJobcard = jobcardService.getJobcardById(jobcard.getId());

	      if (!ObjectUtils.isEmpty(jobcard) && oldJobcard != null) {

	          oldJobcard.setCustomerName(jobcard.getCustomerName());
	          oldJobcard.setMobNumber(jobcard.getMobNumber());
	          oldJobcard.setAddress(jobcard.getAddress());

	          oldJobcard.setCategory(jobcard.getCategory());
	          oldJobcard.setMake(jobcard.getMake());
	          oldJobcard.setModel(jobcard.getModel());

	          oldJobcard.setRegNumber(jobcard.getRegNumber());
	          oldJobcard.setChassisNumber(jobcard.getChassisNumber());
	          oldJobcard.setEngineNumber(jobcard.getEngineNumber());

	          oldJobcard.setKilometers(jobcard.getKilometers());
	          oldJobcard.setJobDate(jobcard.getJobDate());
	          oldJobcard.setJobTime(jobcard.getJobTime());

	          oldJobcard.setServiceType(jobcard.getServiceType());
	          oldJobcard.setDescription(jobcard.getDescription());
	      }

	      Jobcard updatedJobcard = jobcardService.saveJobcard(oldJobcard);

	      if (!ObjectUtils.isEmpty(updatedJobcard)) {
	          session.setAttribute("succMsg", "Jobcard updated successfully");
	      } else {
	          session.setAttribute("errorMsg", "Something went wrong on the server");
	      }

	      return "redirect:/admin/editJobcard/" + jobcard.getId();
	  }

		  
	  @GetMapping("/jobcard")
	    public String loadViewJobcards(Model model,
	                                  @RequestParam(defaultValue = "") String keyword,
	                                  @RequestParam(defaultValue = "0") int pageNo,
	                                  @RequestParam(defaultValue = "10") int pageSize) {

	        Page<Jobcard> page;
	        if (!keyword.isEmpty()) {
	            page = jobcardService.searchJobcardPagination(pageNo, pageSize, keyword);
	        } else {
	            page = jobcardService.getAllJobcardPagination(pageNo, pageSize);
	        }

	        model.addAttribute("jobcard", page.getContent());
	        model.addAttribute("pageNo", page.getNumber());
	        model.addAttribute("pageSize", pageSize);
	        model.addAttribute("totalElements", page.getTotalElements());
	        model.addAttribute("totalPages", page.getTotalPages());
	        model.addAttribute("isFirst", page.isFirst());
	        model.addAttribute("isLast", page.isLast());
	        model.addAttribute("keyword", keyword);

	        return "admin/jobcard";  // Thymeleaf template: src/main/resources/templates/admin/jobcard.html
	    }
	

	  
	  
	@GetMapping("/deletejobcard/{id}")
    public String deleteJobcard(@PathVariable Integer id, HttpSession session) {
        boolean deleted = jobcardService.deleteJobcard(id);
        if (deleted) {
            session.setAttribute("succMsg", "Jobcard deleted successfully");
        } else {
            session.setAttribute("errorMsg", "Failed to delete Jobcard");
        }
        return "redirect:/admin/jobcard";
    }
	
	@GetMapping("/viewJobcard/{id}")
    public String viewJobcard(@PathVariable("id") Integer id, Model model) {
        Jobcard jobcard = jobcardService.getJobcardById(id);
        if (jobcard == null) {
            return "redirect:/admin/jobcard?error=notFound";
        }
        model.addAttribute("jobcard", jobcard);
        return "admin/jobcard_view"; // Template path: /templates/admin/jobcard_view.html
    }
	
	/*
	 * @GetMapping("/admin/downloadJobcardPdf/{id}") public void
	 * downloadJobcardPdf(@PathVariable("id") Integer id, HttpServletResponse
	 * response) throws IOException { Jobcard jobcard =
	 * jobcardService.getJobcardById(id);
	 * 
	 * if (jobcard == null) { response.sendError(HttpServletResponse.SC_NOT_FOUND,
	 * "Jobcard not found"); return; }
	 * 
	 * response.setContentType("application/pdf");
	 * response.setHeader("Content-Disposition", "attachment; filename=jobcard_" +
	 * id + ".pdf");
	 * 
	 * try { Document document = new Document(PageSize.A4);
	 * PdfWriter.getInstance(document, response.getOutputStream());
	 * 
	 * document.open();
	 * 
	 * Font titleFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD); Font
	 * labelFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD); Font
	 * valueFont = new Font(Font.FontFamily.HELVETICA, 12);
	 * 
	 * Paragraph title = new Paragraph("JOB CARD", titleFont);
	 * title.setAlignment(Element.ALIGN_CENTER); document.add(title);
	 * document.add(Chunk.NEWLINE);
	 * 
	 * PdfPTable table = new PdfPTable(2); table.setWidthPercentage(100);
	 * table.setSpacingBefore(10f); table.setSpacingAfter(10f);
	 * 
	 * addRow(table, "JobCard No:", jobcard.getJobCardNumber(), labelFont,
	 * valueFont); addRow(table, "Date:", String.valueOf(jobcard.getJobDate()),
	 * labelFont, valueFont); addRow(table, "Time:",
	 * String.valueOf(jobcard.getJobTime()), labelFont, valueFont); addRow(table,
	 * "Kilometers:", String.valueOf(jobcard.getKilometers()), labelFont,
	 * valueFont); addRow(table, "Reg Number:", jobcard.getRegNumber(), labelFont,
	 * valueFont); addRow(table, "Customer Name:", jobcard.getCustomerName(),
	 * labelFont, valueFont); addRow(table, "Mobile Number:",
	 * jobcard.getMobNumber(), labelFont, valueFont); addRow(table, "Address:",
	 * jobcard.getAddress(), labelFont, valueFont); addRow(table, "Service Type:",
	 * jobcard.getServiceType(), labelFont, valueFont); addRow(table, "Category:",
	 * jobcard.getCategory(), labelFont, valueFont); addRow(table, "Make:",
	 * jobcard.getMake(), labelFont, valueFont); addRow(table, "Model:",
	 * jobcard.getModel(), labelFont, valueFont); addRow(table, "Chassis Number:",
	 * jobcard.getChassisNumber(), labelFont, valueFont); addRow(table,
	 * "Engine Number:", jobcard.getEngineNumber(), labelFont, valueFont);
	 * addRow(table, "Description:", jobcard.getDescription(), labelFont,
	 * valueFont);
	 * 
	 * document.add(table); document.close(); } catch (DocumentException e) { throw
	 * new IOException("Error generating PDF: " + e.getMessage()); } }
	 * 
	 * private void addRow(PdfPTable table, String label, String value, Font
	 * labelFont, Font valueFont) { PdfPCell cell1 = new PdfPCell(new Phrase(label,
	 * labelFont)); PdfPCell cell2 = new PdfPCell(new Phrase(value != null ? value :
	 * "", valueFont));
	 * 
	 * cell1.setBorder(Rectangle.NO_BORDER); cell2.setBorder(Rectangle.NO_BORDER);
	 * 
	 * table.addCell(cell1); table.addCell(cell2); }
	 */
	
		/* End Jobcard Code */

	
	
	/*--------------------------------------------------------------------------------------------------------------------------------*/
	
	
}
