package com.ecom.service;

import java.util.List;
import com.ecom.model.Part;

public interface PartService {

    // Fetch all parts
    List<Part> getAllParts();

    // Save new part
    Part savePart(Part part);

    // Get part by ID
    Part getPartById(Long id);

    // Update existing part by ID
    Part updatePart(Long id, Part updatedPart);

    // Update stock of part
    boolean updateStock(Long id, int newStock);

    // Delete part by ID
    void deletePart(Long id);
    
    boolean existsByPartNumber(Part partNumber);
    
}
