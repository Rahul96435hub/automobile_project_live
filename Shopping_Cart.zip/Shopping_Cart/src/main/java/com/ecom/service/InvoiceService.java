package com.ecom.service;

import com.ecom.model.Invoice;
import com.ecom.repository.InvoiceRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InvoiceService {

    private final InvoiceRepository invoiceRepository;

    public InvoiceService(InvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }

    public Invoice saveInvoice(Invoice invoice) {
        // Generate invoice number
        invoice.setInvoiceNumber("INV-" + System.currentTimeMillis());
        invoice.setInvoiceDate(java.time.LocalDate.now());

        // Calculate totals
        double subTotal = 0, totalDiscount = 0;
        for (var part : invoice.getPartEntries()) {
            subTotal += part.getAmount();
            totalDiscount += part.getDiscount();
        }
        double finalAmount = subTotal - totalDiscount;

        invoice.setSubTotal(subTotal);
        invoice.setTotalDiscount(totalDiscount);
        invoice.setFinalAmount(finalAmount);

        return invoiceRepository.save(invoice);
    }

    public List<Invoice> getAllInvoices() {
        return invoiceRepository.findAll();
    }

    public Invoice getInvoiceById(Long id) {
        return invoiceRepository.findById(id).orElse(null);
    }
}
