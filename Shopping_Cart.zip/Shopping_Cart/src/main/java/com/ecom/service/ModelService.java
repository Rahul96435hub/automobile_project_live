package com.ecom.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.ecom.model.Make;
import com.ecom.model.Model;

public interface ModelService {

    public Model saveModel(Model model);

    public Boolean existModel(String name);

    public List<Model> getAllModel();

    public Boolean deleteModel(int id);

    public Model getModelById(int id);

    public List<Model> getAllActiveModel();
    
    
    /* Start Model pigion Page crate */
    
	  Page<Model> getAllModelPagination(int pageNo, int pageSize);
	    Page<Model> searchModelPagination(int pageNo, int pageSize, String keyword);

	 
		/* End Model Page crate */
    
    
    
  
}
