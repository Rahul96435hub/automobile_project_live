package com.ecom.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.ecom.model.Category;
import com.ecom.repository.CategoryRepository;
import com.ecom.service.CategeoryService;

@Service
public class CategoryServiceImpl implements CategeoryService {
	
	@Autowired
	private CategoryRepository CategoryRepository;

	@Override
	public Category saveCategory(Category category) {
		
		return CategoryRepository.save(category);
	}


	@Override
	public List<Category> getAllCategory() {
		
		return CategoryRepository.findAll();
	}
	
	@Override
	public Boolean existCatgory(String name) {
		
		return CategoryRepository.existsByName(name);
	}


	@Override
	public Boolean deleteCategory(int id) {
		Category category = CategoryRepository.findById(id).orElse(null);
		if (!ObjectUtils.isEmpty(category)) {
			CategoryRepository.delete(category);
			return true;
		}
		return false;
	}


	@Override
	public Category getCategoryById(int id) {
		Category category = CategoryRepository.findById(id).orElse(null);
		return category;
	}
	
	
	@Override
	public List<Category> getAllActiveCategory() {
		List<Category> categories = CategoryRepository.findByIsActiveTrue();
		return categories;
	}
	

}
