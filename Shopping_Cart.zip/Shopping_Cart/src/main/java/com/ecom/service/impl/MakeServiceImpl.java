package com.ecom.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.ecom.model.Jobcard;
import com.ecom.model.Make;
import com.ecom.repository.MakeRepository;
import com.ecom.service.MakeService;

@Service
public class MakeServiceImpl implements MakeService {

    @Autowired
    private MakeRepository makeRepository;

    @Override
    public Make saveMake(Make make) {
        return makeRepository.save(make);
    }

    @Override
    public List<Make> getAllMake() {
        return makeRepository.findAll();
    }

    @Override
    public Boolean existMake(String name) {
        return makeRepository.existsByName(name);
    }

    @Override
    public Boolean deleteMake(int id) {
        Make make = makeRepository.findById(id).orElse(null);
        if (!ObjectUtils.isEmpty(make)) {
            makeRepository.delete(make);
            return true;
        }
        return false;
    }

    @Override
    public Make getMakeById(int id) {
        return makeRepository.findById(id).orElse(null);
    }

    @Override
    public List<Make> getAllActiveMake() {
        return makeRepository.findByIsActiveTrue();
    }
    
/* Start Make pigion Page crate */
  

    @Override
    public Page<Make> getAllMakePagination(int pageNo, int pageSize) {
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        return makeRepository.findAll(pageable);
    }

    @Override
    public Page<Make> searchMakePagination(int pageNo, int pageSize, String keyword) {
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        return makeRepository.findByNameContainingIgnoreCase(keyword, pageable);
    }
	
	/* End Make pigion Page crate */
    
   
}
