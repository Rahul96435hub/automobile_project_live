package com.ecom.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.ecom.model.Make;
import com.ecom.model.Model;
import com.ecom.repository.ModelRepository;
import com.ecom.service.ModelService;

@Service
public class ModelServiceImpl implements ModelService {

    @Autowired
    private ModelRepository modelRepository;

    @Override
    public Model saveModel(Model model) {
        return modelRepository.save(model);
    }

    @Override
    public List<Model> getAllModel() {
        return modelRepository.findAll();
    }

    @Override
    public Boolean existModel(String name) {
        return modelRepository.existsByName(name);
    }

    @Override
    public Boolean deleteModel(int id) {
        Model model = modelRepository.findById(id).orElse(null);
        if (!ObjectUtils.isEmpty(model)) {
            modelRepository.delete(model);
            return true;
        }
        return false;
    }

    @Override
    public Model getModelById(int id) {
        return modelRepository.findById(id).orElse(null);
    }

    @Override
    public List<Model> getAllActiveModel() {
        return modelRepository.findByIsActiveTrue();
    }
    /* Start Model pigion Page crate */
    

    public Page<com.ecom.model.Model> searchModelPagination(int pageNo, int pageSize, String keyword) {
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        return modelRepository.findByNameContainingIgnoreCase(keyword, pageable);
    }

    public Page<com.ecom.model.Model> getAllModelPagination(int pageNo, int pageSize) {
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        return modelRepository.findAll(pageable);
    }
	
	/* End Make pigion Page crate */
   
}
