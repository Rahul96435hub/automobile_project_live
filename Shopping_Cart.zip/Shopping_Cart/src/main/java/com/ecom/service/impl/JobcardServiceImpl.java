package com.ecom.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.multipart.MultipartFile;



import java.io.ByteArrayOutputStream;

import com.ecom.model.Jobcard;
import com.ecom.model.Product;
import com.ecom.repository.JobcardRepository;
import com.ecom.service.JobcardService;

@Service
public class JobcardServiceImpl implements JobcardService {

    @Autowired
    private JobcardRepository jobcardRepository;

    @Override
    public Jobcard saveJobcard(Jobcard jobcard) {
        return jobcardRepository.save(jobcard);
    }

    @Override
    public List<Jobcard> getAllJobcard() {
        return jobcardRepository.findAll();
    }

    @Override
    public Page<Jobcard> getAllJobcardPagination(Integer pageNo, Integer pageSize) {
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        return jobcardRepository.findAll(pageable);
    }

    

    @Override
    public Jobcard getJobcardById(Integer id) {
        return jobcardRepository.findById(id).orElse(null);
    }

    @Override
    public Jobcard updateJobcard(Jobcard jobcard, MultipartFile file) {
        // Assuming file handling is not required for jobcard. If yes, add file handling logic.
        return jobcardRepository.save(jobcard);
    }

    @Override
    public List<Jobcard> searchJobcard(String ch) {
        return jobcardRepository.findByCustomerNameContainingIgnoreCase(ch);
    }

    @Override
    public Page<Jobcard> searchJobcardPagination(Integer pageNo, Integer pageSize, String ch) {
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        return jobcardRepository.findByCustomerNameContainingIgnoreCase(ch, pageable);
    }

    // Placeholder methods if needed later
    @Override
    public List<Jobcard> getAllActiveJobcard(String category) {
        return null;
    }

    @Override
    public Page<Jobcard> getAllActiveJobcardPagination(Integer pageNo, Integer pageSize, String category) {
        return null;
    }

    @Override
    public Page<Jobcard> searchActiveJobcardPagination(Integer pageNo, Integer pageSize, String category, String ch) {
        return null;
    }

    @Override
    public List<Jobcard> getAllJobCard() {
        return getAllJobcard();
    }

    public Boolean deleteJobcard(Integer id) {
        try {
            jobcardRepository.deleteById(id);
            return true;  // deletion successful
        } catch (Exception e) {
            e.printStackTrace();
            return false; // deletion failed
        }
    }
    
    
    


   

    
}
