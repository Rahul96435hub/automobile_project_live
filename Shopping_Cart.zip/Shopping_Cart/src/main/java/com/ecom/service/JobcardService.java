package com.ecom.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.web.multipart.MultipartFile;

import com.ecom.model.Jobcard;

public interface JobcardService {

	public Jobcard saveJobcard(Jobcard jobcard);

	List<Jobcard> getAllJobcard();

	public List<Jobcard> getAllJobCard();

	public Boolean deleteJobcard(Integer id);

	public Jobcard getJobcardById(Integer id);

	public Jobcard updateJobcard(Jobcard jobcard, MultipartFile file);

	public List<Jobcard> getAllActiveJobcard(String category);

	public List<Jobcard> searchJobcard(String ch);

	public Page<Jobcard> getAllActiveJobcardPagination(Integer pageNo, Integer pageSize, String category);

	public Page<Jobcard> searchJobcardPagination(Integer pageNo, Integer pageSize, String ch);

	public Page<Jobcard> getAllJobcardPagination(Integer pageNo, Integer pageSize);

	public Page<Jobcard> searchActiveJobcardPagination(Integer pageNo, Integer pageSize, String category, String ch);
	
	/*
	 * public Page<Jobcard> searchJobcardPagination(int pageNo, int pageSize, String
	 * keyword) { Pageable pageable = PageRequest.of(pageNo, pageSize); return
	 * jobcardRepository.findByRegNumberContainingIgnoreCase(keyword, pageable); }
	 */
	
	}
	
	


