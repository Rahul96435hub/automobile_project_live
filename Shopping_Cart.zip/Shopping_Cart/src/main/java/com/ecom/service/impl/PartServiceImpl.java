package com.ecom.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import com.ecom.model.Part;
import com.ecom.repository.PartEntryRepository;
import com.ecom.repository.PartRepository;
import com.ecom.service.PartService;


@Service
public class PartServiceImpl implements PartService {

    @Autowired
    private PartRepository partRepository;

    @Override
    public List<Part> getAllParts() {
        return partRepository.findAll();
    }

    @Override
    public Part savePart(Part part) {
        return partRepository.save(part);
    }

    @Override
    public Part getPartById(Long id) {
        Optional<Part> optional = partRepository.findById(id);
        return optional.orElse(null);
    }

    @Override
    public Part updatePart(Long id, Part updatedPart) {
        Part existingPart = getPartById(id);
        if (existingPart != null) {
            existingPart.setPartNumber(updatedPart.getPartNumber());
            existingPart.setDescription(updatedPart.getDescription());
            existingPart.setType(updatedPart.getType());
            existingPart.setStatus(updatedPart.getStatus());
            existingPart.setRate(updatedPart.getRate());
            existingPart.setMrp(updatedPart.getMrp());
            existingPart.setDiscount(updatedPart.getDiscount());
            existingPart.setAmt(updatedPart.getAmt());
            existingPart.setFinalAmt(updatedPart.getFinalAmt());
            existingPart.setVendorName(updatedPart.getVendorName());
            existingPart.setVendorInvoiceNo(updatedPart.getVendorInvoiceNo());
            return partRepository.save(existingPart);
        }
        return null;
    }

    @Override
    public boolean updateStock(Long id, int newStock) {
        Part part = getPartById(id);
        if (part != null) {
            part.setStock(newStock);
            partRepository.save(part);
            return true;
        }
        return false;
    }

    @Override
    public void deletePart(Long id) {
        partRepository.deleteById(id);
    }

	@Override
	public boolean existsByPartNumber(Part partNumber) {
		// TODO Auto-generated method stub
		return false;
	}
 
}