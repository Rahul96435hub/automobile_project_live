package com.ecom.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.ecom.model.Jobcard;
import com.ecom.model.Make;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
	

public interface MakeService {
    
    public Make saveMake(Make make);
        	
	  public Boolean existMake(String name);
	  
	  public List<Make> getAllMake();
	  
	  public Boolean deleteMake(int id);
	  
	  public Make getMakeById(int id);
	  
	  public List<Make> getAllActiveMake();
	  
	  /* Start Make pigion Page crate */
	  Page<Make> getAllMakePagination(int pageNo, int pageSize);
	    Page<Make> searchMakePagination(int pageNo, int pageSize, String keyword);

	  
		
		/* End Make pigion Page crate */

	 
}
