package com.ecom.model;

public class CheckDTO {
    private String partNumber;
    private int qty;

    public CheckDTO() {
    }

    public CheckDTO(String partNumber, int qty) {
        this.partNumber = partNumber;
        this.qty = qty;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }
}

