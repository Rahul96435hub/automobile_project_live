package com.ecom.model;

import jakarta.persistence.*;

@Entity
@Table(name = "part")
public class Part {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "part_number", nullable = false, unique = true)
    private String partNumber;

    @Column(nullable = false)
    private String description;

    @Column(nullable = false)
    private String type;

    @Column(nullable = false)
    private String status;

    // primitive types:
    @Column(nullable = false)
    private double mrp;

    @Column(nullable = false)
    private double rate;

    @Column(nullable = false)
    private Integer stock;

    @Column(nullable = false)
    private Double  discount;  // in percentage

    @Column(nullable = false)
    private double amt;    // rate * stock

    @Column(name = "final_amt", nullable = false)
    private double finalAmt;  // after discount

    @Column(name = "vendor_name", nullable = false)
    private String vendorName;

    @Column(name = "vendor_invoice_no", nullable = false)
    private String vendorInvoiceNo;

    // getters & setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getPartNumber() { return partNumber; }
    public void setPartNumber(String partNumber) { this.partNumber = partNumber; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public double getMrp() { return mrp; }
    public void setMrp(double mrp) { this.mrp = mrp; }

    public double getRate() { return rate; }
    public void setRate(double rate) { this.rate = rate; }

    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    public Double getDiscount() { return discount; }
    public void setDiscount(Double discount) { this.discount = discount; }

    public double getAmt() { return amt; }
    public void setAmt(double amt) { this.amt = amt; }

    public double getFinalAmt() { return finalAmt; }
    public void setFinalAmt(double finalAmt) { this.finalAmt = finalAmt; }

    public String getVendorName() { return vendorName; }
    public void setVendorName(String vendorName) { this.vendorName = vendorName; }

    public String getVendorInvoiceNo() { return vendorInvoiceNo; }
    public void setVendorInvoiceNo(String vendorInvoiceNo) { this.vendorInvoiceNo = vendorInvoiceNo; }
}
