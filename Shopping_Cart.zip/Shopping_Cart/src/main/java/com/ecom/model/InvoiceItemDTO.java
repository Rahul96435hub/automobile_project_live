package com.ecom.model;

public class InvoiceItemDTO {
    private String partNumber;
    private int qty;

    // Getters and Setters
    public String getPartNumber() {
        return partNumber;
    }
    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }
    public int getQty() {
        return qty;
    }
    public void setQty(int qty) {
        this.qty = qty;
    }
}

