package com.ecom.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecom.model.PartEntry;

import java.util.List;

public interface PartEntryRepository extends JpaRepository<PartEntry, Long> {
	
	//List<PartEntry> findByPartNumber(String partNumber);
	
	
}
