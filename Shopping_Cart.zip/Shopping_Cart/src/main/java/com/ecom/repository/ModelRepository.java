package com.ecom.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.ecom.model.Make;
import com.ecom.model.Model;

public interface ModelRepository extends JpaRepository<Model, Integer> {
    
    public Boolean existsByName(String name);

    public List<Model> findByIsActiveTrue();
    
/* Start Model pigion Page crate */
	
	Page<Model> findByNameContainingIgnoreCase(String keyword, Pageable pageable);
	
	/* End Model pigion Page crate */

}
