package com.ecom.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ecom.model.Part;

@Repository
public interface PartRepository extends JpaRepository<Part, Long> {

    // You can add custom query methods here if needed
	
	Part findByPartNumber(String partNumber);
	
	
	
	boolean existsByPartNumber(String partNumber);
	
	
}
