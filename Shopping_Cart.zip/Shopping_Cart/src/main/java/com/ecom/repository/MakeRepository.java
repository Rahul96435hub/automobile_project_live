 package com.ecom.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

/* Start Make pigion Page package */
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
/* End Make pigion Page Package */

import com.ecom.model.Jobcard;
import com.ecom.model.Make;

public interface MakeRepository extends JpaRepository<Make, Integer> {
	
	public Boolean existsByName(String name);

	public List<Make> findByIsActiveTrue();
	
	/* Start Make pigion Page crate */
	
	Page<Make> findByNameContainingIgnoreCase(String keyword, Pageable pageable);
	
	/* End Make pigion Page crate */
}
