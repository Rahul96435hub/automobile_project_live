package com.ecom.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;



import com.ecom.model.Jobcard;


public interface JobcardRepository extends JpaRepository<Jobcard, Integer>  {
	
	List<Jobcard> findByCustomerNameContainingIgnoreCase(String keyword);
	
	Page<Jobcard> findByCustomerNameContainingIgnoreCase(String keyword, Pageable pageable);
	
	Page<Jobcard> findByRegNumberContainingIgnoreCase(String keyword, Pageable pageable);
	
	

}
	
