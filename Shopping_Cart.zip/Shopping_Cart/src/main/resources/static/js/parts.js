




document.addEventListener("DOMContentLoaded", () => {
  const tableBody = document.getElementById("partsBody");
  const addBtn = document.getElementById("addRowBtn");

  addBtn.addEventListener("click", () => addRow());

  function addRow() {
    const row = tableBody.insertRow();
    const rowIndex = tableBody.rows.length;

    row.innerHTML = `
      <td>${rowIndex}</td>
      <td><input type="text" class="partNum" placeholder="Enter Part #" /></td>
      <td class="desc"></td>
      <td class="type"></td>
      <td class="status"></td>
      <td class="discount"></td>
      <td class="rate"></td>
      <td><input type="number" min="1" class="qty" value="1" /></td>
      <td class="amount"></td>
      <td><button class="deleteBtn">🗑️</button></td>
    `;

    const partInput = row.querySelector(".partNum");
    const qtyInput = row.querySelector(".qty");

    partInput.addEventListener("keydown", async (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        const partNum = partInput.value.trim().toUpperCase();
        const data = await fetch(`/api/parts/${partNum}`);
        if (!data.ok) {
          alert("Invalid Part Number!");
          return;
        }
        const part = await data.json();
        row.querySelector(".desc").textContent = part.desc;
        row.querySelector(".type").textContent = part.type;
        row.querySelector(".status").textContent = part.status;
        row.querySelector(".discount").textContent = part.discount;
        row.querySelector(".rate").textContent = part.rate;
        updateAmount();
      }
    });

    qtyInput.addEventListener("input", updateAmount);

    function updateAmount() {
      const qty = parseInt(qtyInput.value || 0);
      const rate = parseFloat(row.querySelector(".rate").textContent || 0);
      const discount = parseFloat(row.querySelector(".discount").textContent || 0);
      const amount = ((rate * qty) * (1 - discount / 100)).toFixed(2);
      row.querySelector(".amount").textContent = isNaN(amount) ? '' : amount;
    }

    row.querySelector(".deleteBtn").addEventListener("click", () => {
      row.remove();
      updateSrNo();
    });
  }

  function updateSrNo() {
    Array.from(tableBody.rows).forEach((r, i) => {
      r.cells[0].textContent = i + 1;
    });
  }

  // Add initial row
  addRow();
});
