async function fetchJobcardData() {
  const response = await fetch('/api/jobcard/123'); // your real API URL
  if (!response.ok) throw new Error('Network error');
  return await response.json();
}
